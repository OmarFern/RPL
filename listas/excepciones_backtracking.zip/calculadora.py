from mate import sumar

print(sumar(10,10))