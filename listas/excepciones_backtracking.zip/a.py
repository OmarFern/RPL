
if __name__ == '__main__':
    print("Gracias por ejecutar a.py!")
    print(__name__)